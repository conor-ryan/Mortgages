import EstimationFunctions as ef
import multiprocessing as mp
import numpy as np

### Consumer Data List Function
## Parallel functions need a list of arguments.
## This function pre-processes all of the consumer inputs into a list
# theta - parameter object 
# cdf  - consumer/loan level data frame
# mdf  - market level data frame
# mbsdf - MBS coupon price data frame
## Output
# A list of named lists where each item has two entries:
# --- dat - consumer "Data" object
# --- mbs - MBS price interpolation object 

def consumer_object_list(theta,cdf,mdf,mbsdf):
    consumer_list = list()
    for i in range(cdf.shape[0]):
        dat,mbs = ef.consumer_subset(i,theta,cdf,mdf,mbsdf)
        consumer_list.append({'dat':dat,'mbs':mbs})
    return consumer_list

#### Worker Evaluation Wrappers ####
## Each worker will take a set of arguments and output the relevant values 
## These functions simply wrap the consumer likelihood evaluation functions in EstimationFunctions
## One function for likelihood, gradient, and hessian.
## Inputs
# theta - parameter object
# list_object - an item in the consumer object list
## Outputs
# Same as the associated consumer likelihood evaluation function (without iteration count)
def worker_likelihood(theta,list_object):
    ll_i,q0_i,w_i,itr  = ef.consumer_likelihood_eval(theta,list_object['dat'],list_object['mbs'])
    return ll_i,q0_i,w_i

def worker_likelihood_gradient(theta,list_object):
    ll_i,dll_i,q0_i,dq0_i,w_i,dw_i,itr  = ef.consumer_likelihood_eval_gradient(theta,list_object['dat'],list_object['mbs'])
    return ll_i,dll_i,q0_i,dq0_i,w_i,dw_i

def worker_likelihood_hessian(theta,list_object):
    ll_i,dll_i,d2ll_i,q0_i,dq0_i,d2q0_i,w_i,dw_i,d2w_i,itr   = ef.consumer_likelihood_eval_hessian(theta,list_object['dat'],list_object['mbs'])
    return ll_i,dll_i,d2ll_i,q0_i,dq0_i,d2q0_i,w_i,dw_i,d2w_i

#### Parallel Mapping Functions ####
## These functions implement python parallelization to the worker evaluation wrappers
# Inputs
# xlist - a list of arguments (theta,clist), where clist is an item in the consumer list object
# num_workers - number of threads to use in parallel
# Outputs
# res - a list of lists. 
# --- Each item in the outer list is a consumer
# --- Each item in the inner list is an output from the worker-level evaluation functoin
def eval_map_likelihood(xlist,num_workers):
    p = mp.Pool(num_workers) # Initialize parallel workers
    res = p.starmap(worker_likelihood, xlist) # Evaluate in parallel
    p.close() # Close parallel workers
    return res

def eval_map_likelihood_gradient(xlist,num_workers):
    p = mp.Pool(num_workers) # Initialize parallel workers
    res = p.starmap(worker_likelihood_gradient, xlist) # Evaluate in parallel
    p.close() # Close parallel workers
    return res

def eval_map_likelihood_hessian(xlist,num_workers):
    p = mp.Pool(num_workers) # Initialize parallel workers
    res = p.starmap(worker_likelihood_hessian, xlist) # Evaluate in parallel
    p.close() # Close parallel workers
    return res


###### Functions to Evaluate Full Likelihood Function in Parallel #####
## Similarly, three functions for objective, gradient, and hessian. 

### Evaluate Likelihood Function 
# Inputs
# x - Candidate parameter vector
# theta - parameter object (with specifications)
# clist - consumer data object list
# num_workers - threads to use in parallel
# Outputs
# ll - log likelihood 
def evaluate_likelihood_parallel(x,theta,clist,num_workers):
    # Print candidate parameter guess 
    print("Parameters:", x)
    # Set parameters in the parameter object
    theta.set(x)
    # Initialize Aggregate Share Variables
    pred_N = np.zeros(len(theta.out_share))
    pred_N_out = np.zeros(len(theta.out_share))
    ll_market = np.zeros(len(theta.out_share))

    ## Evaluate each consumer in parallel 
    args = [(theta,c_val) for c_val in clist]
    res = eval_map_likelihood(args,num_workers)

    # Iterate over all consumers to compute likelihood
    for i in range(len(res)):
        # Unpack parallel results
        dat= clist[i]['dat']
        ll_i,q0_i,w_i = res[i]
        #Compute outside option takeup
        pred_N[dat.out] += w_i
        pred_N_out[dat.out] += q0_i*w_i
        # Add contribution to total likelihood
        ll_market[dat.out] +=ll_i*w_i

    # Combine Micro and Macro Likelihood Moments
    pred_out_share = pred_N_out/pred_N
    ll_macro = np.sum(theta.N*(theta.out_share*np.log(pred_out_share)))# + (1-theta.out_share)*np.log(1-pred_out_share)))
    ll = np.sum(theta.N*(1-theta.out_share)*ll_market/pred_N) + ll_macro
    # Print and output likelihood value
    print("Likelihood:",ll, "Outside Share:", pred_out_share)
    return ll

### Evaluate Likelihood Function with Gradient
# Inputs
# x - Candidate parameter vector
# theta - parameter object (with specifications)
# clist - consumer data object list
# num_workers - threads to use in parallel
# Outputs
# ll - log likelihood 
# dll - gradient of log likelihood 
def evaluate_likelihood_gradient_parallel(x,theta,clist,num_workers):
    # Print candidate parameter guess 
    print("Parameters:", x)
    # Set parameters in the parameter object
    theta.set(x)   

    # Initialize Aggregate Share Variables
    # Necessary for matching outside option, and correcting selection into the sample
    # Predicted outside option takeup
    pred_N_out = np.zeros(len(theta.out_share))
    # Adaptive weights to correct selection and derivatives
    pred_N = np.zeros(len(theta.out_share))
    dpred_N = np.zeros((len(theta.out_share),len(x)))
    
    # Likelihood value per market (defined by outside option) and gradient 
    ll_market = np.zeros(len(theta.out_share))
    dll_market = np.zeros((len(theta.out_share),len(x)))

    ## Evaluate each consumer in parallel 
    args = [(theta,c_val) for c_val in clist]
    res = eval_map_likelihood_gradient(args,num_workers)

    # Iterate over all consumers to compute likelihood
    for i in range(len(res)):
        # Unpack parallel results
        dat= clist[i]['dat']
        ll_i,dll_i,q0_i,dq0_i,w_i,dw_i = res[i]
        # Add outside option, probability weights, and derivatives
        pred_N[dat.out] += w_i
        pred_N_out[dat.out] += q0_i*w_i
        dpred_N[dat.out,:] += dw_i
        # Add contribution to total likelihood, gradient and hessian (by outside option market)
        # Derivatives need to account for the fact that the likelihood is weighted
        ll_market[dat.out] +=ll_i*w_i
        dll_market[dat.out,:] += dll_i*w_i + ll_i*dw_i
    
    # Compute Macro Likelihood Component and Gradient
    pred_out_share = pred_N_out/pred_N # Predicted outside option share
    ll_macro = np.sum(theta.N*(theta.out_share*np.log(pred_out_share)))
    # Initialize objects to hold gradient
    dll_macro = np.zeros(len(x))
    # Sum across the outside option markets
    for i in range(len(theta.out_share)):
        # Gradient of the log-weighted-outside option
        d_log_out = dpred_N[i,:]*(1/pred_N_out[i] - 1/pred_N[i])
        # Weight by actual population size in macro component
        dll_macro += theta.N[i]*(theta.out_share[i]*d_log_out)

    # Compute total log likelihood
    # Micro-likelihood is renormalized by sum of the weights, then weighted by actual population
    ll = np.sum(theta.N*(1-theta.out_share)*ll_market/pred_N) + ll_macro
    
    # Initialize log likelihood gradient 
    dll = dll_macro # Start with macro component
    # Sum across outside option markets
    for i in range(len(theta.out_share)):
        # Gradient of the micro-log likelihood
        dll += theta.N[i]*(1-theta.out_share[i])*(dll_market[i,:]/pred_N[i] +\
                - dpred_N[i,:]*ll_market[i]/pred_N[i]**2) 
        
    # Print and output likelihood value
    print("Likelihood:",ll, "Outside Share:", pred_out_share)
    return ll, dll

### Evaluate Likelihood Function with Gradient and Hessian
# Inputs
# x - Candidate parameter vector
# theta - parameter object (with specifications)
# clist - consumer data object list
# num_workers - threads to use in parallel
# Outputs
# ll - log likelihood 
# dll - gradient of log likelihood 
# d2ll - hessian of log likelihood 
def evaluate_likelihood_hessian_parallel(x,theta,clist,num_workers):
    # Print candidate parameter guess 
    print("Parameters:", x)
    # Set parameters in the parameter object
    theta.set(x)

    # Initialize Aggregate Share Variables
    # Necessary for matching outside option, and correcting selection into the sample
    # Predicted outside option takeup
    pred_N_out = np.zeros(len(theta.out_share))
    # Adaptive weights to correct selection and derivatives
    pred_N = np.zeros(len(theta.out_share))
    dpred_N = np.zeros((len(theta.out_share),len(x)))
    d2pred_N = np.zeros((len(theta.out_share),len(x),len(x)))
    # Likelihood value per market (defined by outside option) and gradient 
    ll_market = np.zeros(len(theta.out_share))
    dll_market = np.zeros((len(theta.out_share),len(x)))
    d2ll_market = np.zeros((len(theta.out_share),len(x),len(x)))
    
    ## Evaluate each consumer in parallel 
    args = [(theta,c_val) for c_val in clist]
    res = eval_map_likelihood_hessian(args,num_workers)

    # Iterate over all consumers to compute likelihood
    for i in range(len(res)):
        # Unpack parallel results
        dat= clist[i]['dat']
        ll_i,dll_i,d2ll_i,q0_i,dq0_i,d2q0_i,w_i,dw_i,d2w_i = res[i]
        # Add outside option, probability weights, and derivatives
        pred_N_out[dat.out] += q0_i*w_i
        pred_N[dat.out] += w_i
        dpred_N[dat.out,:] += dw_i
        d2pred_N[dat.out,:,:] += d2w_i
        # Add contribution to total likelihood, gradient and hessian (by outside option market)
        # Derivatives need to account for the fact that the likelihood is weighted
        ll_market[dat.out] +=ll_i*w_i
        dll_market[dat.out,:] += dll_i*w_i + ll_i*dw_i
        d2ll_market[dat.out,:,:] += d2ll_i*w_i + ll_i*d2w_i + np.outer(dll_i,dw_i) + np.outer(dw_i,dll_i)

    # Compute Macro Likelihood Component and Gradient
    pred_out_share = pred_N_out/pred_N # Predicted outside option share
    ll_macro = np.sum(theta.N*(theta.out_share*np.log(pred_out_share)))
    # Initialize objects to hold gradient and hessian
    dll_macro = np.zeros(len(x))
    d2ll_macro = np.zeros((len(x),len(x)))
    # Sum across the outside option markets
    for i in range(len(theta.out_share)):
        # Gradient of the log-weighted-outside option
        d_log_out = dpred_N[i,:]*(1/pred_N_out[i] - 1/pred_N[i])
        # Weight by actual population size in macro component
        dll_macro += theta.N[i]*(theta.out_share[i]*d_log_out)

        # Hessian of log-weighted-outside option 
        d2_log_out = d2pred_N[i,:,:]*(1/pred_N_out[i] - 1/pred_N[i]) - np.outer(dpred_N[i,:],dpred_N[i,:])*(1/pred_N_out[i]**2 - 1/pred_N[i]**2) 
        # Weight by actual population size in macro component
        d2ll_macro += theta.N[i]*(theta.out_share[i]*d2_log_out)

    # Compute total log likelihood
    # Micro-likelihood is renormalized by sum of the weights, then weighted by actual population
    ll = np.sum(theta.N*(1-theta.out_share)*ll_market/pred_N) + ll_macro
    
    # Initialize log likelihood gradient, hessian 
    dll = dll_macro # Start with macro component
    d2ll = d2ll_macro # Start with macro component
    # Sum across outside option markets
    for i in range(len(theta.out_share)):
        # Gradient of the micro-log likelihood
        dll += theta.N[i]*(1-theta.out_share[i])*(dll_market[i,:]/pred_N[i] +\
                - dpred_N[i,:]*ll_market[i]/pred_N[i]**2) 
        # Hessian of the micro-log likeliood
        d2ll += theta.N[i]*(1-theta.out_share[i])*(
            d2ll_market[i,:,:]/pred_N[i] +\
            -np.outer(dll_market[i,:],dpred_N[i,:])/pred_N[i]**2 +\
            -np.outer(dpred_N[i,:],dll_market[i,:])/pred_N[i]**2 + \
            -d2pred_N[i,:,:]*ll_market[i]/pred_N[i]**2 +\
            2*np.outer(dpred_N[i,:],dpred_N[i,:])*ll_market[i]/pred_N[i]**3
            ) 

    # Print and output likelihood value
    print("Likelihood:",ll, "Outside Share:", pred_out_share, "Macro ll component:", ll_macro)
    return ll, dll, d2ll


### Newton-Raphson Estimation in Parallel
## Use Newton-Raphson and the analytical hessian matrix to maximize likelihood function 
# Inputs 
# x - starting guess for parameter vector
# theta - parameter object with specification info
# cdf - consumer/loan level data frame
# mdf - market level data frame
# mbdsf - MBS coupon price data frame
# num_workers - threads to use in parallel
# Outputs
# ll_k - maximized likelihood
# x - estimated parameter vector 
def estimate_NR_parallel(x,theta,cdf,mdf,mbsdf,num_workers):
    # Testing Tool: A index of parameters to estimate while holding others constant
    # This can help identification. range(0,len(x)) will estimate all parameters 
    test_index = range(0,len(x))

    # Create list of consumer data (could be memory issue, duplicating data)
    clist = consumer_object_list(theta,cdf,mdf,mbsdf)

    # Set candidate vector in parameter object
    theta.set(x)

    # Initialize "new" candidate parameter vector
    x_new = np.copy(x)
    # Intitial evaluation of likelihood, gradient (f_k), and hessian (B_k)
    ll_k, f_k, B_k = evaluate_likelihood_hessian_parallel(x,theta,clist,num_workers)
    # Translate Hessian into a negative definite matrix for best ascent 
    # Also raises a warning when Hessian is not negitive definite, bad sign if it happens near convergence
    B_k = ef.enforceNegDef(B_k[np.ix_(test_index,test_index)])

    # Initialize error and iteration count
    err = 1
    itr = 0
    # Iterate while error exceeds tolerance
    while err>1e-6:
        # Compute newton step
        p_k = -np.dot(np.linalg.inv(B_k),f_k[test_index])
        # Initial line search value: full newton step
        alpha = 1.0
        # Bound the step size to be one in order to avoid model crashes on odd parameters
        largest_step = np.max(np.abs(p_k))
        alpha = np.minimum(2.0/largest_step,1.0)

        # Compute bounded step
        s_k = alpha*p_k
        # Update potential parameter vector
        x_new[test_index] = x[test_index] + s_k

        # Recompute likelihood, gradient and hessian
        ll_new, f_new, B_new = evaluate_likelihood_hessian_parallel(x_new,theta,clist,num_workers)
        
        # If the initial step leads to a much lower likelihood value
        # shrink the step size to search for a better step.
        line_search = 0  # Initialize line search flag
        while ll_new<ll_k*1.0005: # Allow a small step in the wrong direction
            line_search = 1 # Save that a line search happened
            alpha = alpha/2 # Shrink the step size
            print("Line Search Step Size:",alpha) # Print step size for search
            s_k = alpha*p_k # Compute new step size
            x_new[test_index] = x[test_index] + s_k # Update new candidate parameter vector

            ll_new = evaluate_likelihood_parallel(x_new,theta,clist,num_workers) # Check new value of the likelihood function

        # Update parameter vector after successful step
        x = np.copy(x_new)
        theta.set(x)  
        
        # If no line search was done, update likelihood, gradient and hessian
        if line_search==0:
            ll_k = np.copy(ll_new)
            f_k = np.copy(f_new)
            B_k = np.copy(B_new)
        # If there was a line search, need to evaluate the hessian again
        else:
            ll_k, f_k, B_k = evaluate_likelihood_hessian_parallel(x,theta,clist,num_workers)

        # Check that the hessian is negative definite and enforce it if necessary
        B_k = ef.enforceNegDef(B_k[np.ix_(test_index,test_index)])

        # Evaluate the sum squared error of the gradient of the likelihood function
        err = np.sqrt(np.dot(f_k[test_index],f_k[test_index]))
        # Update iteration count and print error value
        itr+=1 
        print("#### Iteration",itr, "Error", err)

    # Print completion and output likelihood and estimated parameter vector
    print("Completed with Error", err)
    return ll_k, x
