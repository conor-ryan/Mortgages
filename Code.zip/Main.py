import pandas as pd
import numpy as np


from FirstStageFunctions import *
from ModelTypes import *
from EquilibriumFunctions import *
from ModelFunctions import *
from EstimationFunctions import *
from ParallelFunctions import *
from Derivatives import * 

# File with Loan-Level Data
consumer_data_file = "consumer_data.csv"

#### First Stage Specification ####
# Hold/Sell (Defined as Sell=1)
sell_spec = "x6"
# Interest Rates (Interacted with Time Fixed Effects)
# interest_rate_spec = ["x16","x17","x18","x19","x20"]
interest_rate_spec = ["x13","x14"]
mbs_price = "x15" #"x21"
# Consumer/Loan Characteristics
consumer_spec = ["x7","x8"]
# Bank/Aggregate Characteristics - Cost
# bank_spec = ["x22","x23","x24","x25","x26","x27"]
bank_spec = ["x16","x17","x18","x19","x20","x21"]

res, pars = run_first_stage(consumer_data_file,sell_spec,interest_rate_spec,mbs_price,consumer_spec,bank_spec)



#### Second Stage Specification ####
# Consumer/Loan Characteristics - Variables in Consumer Data
consumer_cost_spec = ["x7","x8"]
# Bank Cost Covariates - Variables in Market Data
bank_cost_spec = ["x8","x9","x10","x11","x12","x13"]
# Bank Demand Covariates - Variables in Market Data
bank_dem_spec = ["x3","x4","x5","x6","x7"]

# Discount Factor Covariates ("Time Dummies or Aggregate Data") - Consumer Data
discount_spec = ["x11","x12"]#,"x13","x14","x15"]

# MBS Price Function Specification
# Price variables in MBS data
mbs_spec = ["x2","x3","x4","x5","x6","x7","x8","x9","x10",
              "x11","x12","x13","x14","x15","x16","x17","x18","x19","x20",
              "x21","x22","x23","x24","x25","x26","x27","x28","x29","x30","x31"]
# Corresponding coupon rates
mbs_coupons = np.arange(0.5,15.5,0.5)/100

# Selection and Interest Rate indices
rate_spec = "x5"
lender_spec = "x4" # Market specific, 0,1,2,....
market_spec = "x1" 
time_spec = "x2"
outside_share_index = "x2" # Index ranging 0,1,... that matches consumers to outside share data


## Read in Data 
consumer_data = pd.read_csv("consumer_data.csv") # Consumer/Loan level data
market_data = pd.read_csv("market_data.csv") # Market level data
mbs_data = pd.read_csv("mbs_data.csv") # MBS coupon price data
share_data = pd.read_csv("share_data.csv") # Aggregate share data

theta = Parameters(bank_dem_spec,bank_cost_spec,consumer_spec,discount_spec,
                   mbs_spec,mbs_coupons,
                   rate_spec,lender_spec,market_spec,time_spec,outside_share_index,
                   pars,
                   share_data["x4"],share_data["x5"])

initial_parameters = np.array([12.9,12.6, 12.4, 12.2,12.0, # Beta_x
                   0.1, 0.1, 0.2, 0.2, 0.7, -3.0, #Gamma_WH
                   0.1,-0.1]) # Gamma_ZH

f_val, res = estimate_NR_parallel(initial_parameters,theta,consumer_data,market_data,mbs_data,4)



